"""
Generates a short synthetic buzzer tone (assets/buzzer.wav) using only the
Python standard library, so the project ships no third-party audio asset.
"""
import math
import struct
import wave
from pathlib import Path

ASSETS_DIR = Path(__file__).parent / "assets"


def generate_buzzer(path=None, freq=880, duration=1.0, volume=0.5, sample_rate=44100):
    path = Path(path) if path else (ASSETS_DIR / "buzzer.wav")
    path.parent.mkdir(parents=True, exist_ok=True)
    n_samples = int(sample_rate * duration)
    with wave.open(str(path), "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        for i in range(n_samples):
            t = i / sample_rate
            sample = volume * math.sin(2 * math.pi * freq * t)
            wav_file.writeframes(struct.pack("<h", int(sample * 32767)))
    return path


if __name__ == "__main__":
    out = generate_buzzer()
    print(f"Buzzer tone written to {out}")
