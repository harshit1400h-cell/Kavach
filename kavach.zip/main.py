"""
Project Kavach — local hackathon prototype (detection engine).

Uses your laptop webcam as the "bus CCTV" feed and watches for:
  1. A distress hand gesture (heuristic "signal for help", see gesture_utils.py)
  2. Driver drowsiness — eyes closed for 2+ seconds, via Eye Aspect Ratio (see ear_utils.py)

On trigger it:
  - Draws a flashing red border + label on the video window
  - Plays a local buzzer sound
  - Writes status.json, which dashboard.py (Streamlit) polls and displays
  - Optionally sends a real SMS via Twilio (configure in alerts.py / .env)

Run:    python main.py
Quit:   press 'q' with the video window focused

Also run `streamlit run dashboard.py` in a second terminal to see the
central command center update live.
"""
import threading
import time

import cv2
import mediapipe as mp

from alerts import send_sms_alert, write_status
from ear_utils import average_ear
from gesture_utils import is_distress_gesture
from make_buzzer import ASSETS_DIR, generate_buzzer

# ---------------- tunables ----------------
EAR_THRESHOLD = 0.21          # below this, eyes are considered "closed"
EAR_CONSEC_SECONDS = 2.0      # must stay closed this long to count as drowsy
GESTURE_HOLD_SECONDS = 0.6    # gesture must be held this long to avoid false triggers
COOLDOWN_SECONDS = 8.0        # minimum gap between repeated alerts of the same type
CAMERA_INDEX = 0

mp_hands = mp.solutions.hands
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils


def play_buzzer_async():
    """Plays the buzzer on a background thread so it never blocks the video loop."""
    def _play():
        try:
            from playsound import playsound
            wav_path = ASSETS_DIR / "buzzer.wav"
            if not wav_path.exists():
                generate_buzzer(wav_path)
            playsound(str(wav_path))
        except Exception as e:
            # Falls back to a terminal bell if audio playback isn't available
            print("\a[main] Buzzer playback unavailable:", e)

    threading.Thread(target=_play, daemon=True).start()


def main():
    generate_buzzer()  # make sure assets/buzzer.wav exists before we ever need it

    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        raise RuntimeError(
            f"Could not open webcam (index {CAMERA_INDEX}). "
            "Try a different CAMERA_INDEX at the top of main.py."
        )

    hands = mp_hands.Hands(
        max_num_hands=2,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.5,
    )
    face_mesh = mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.5,
    )

    eyes_closed_since = None
    gesture_since = None
    last_gesture_alert = 0.0
    last_drowsy_alert = 0.0

    print("Project Kavach demo running. Press 'q' in the video window to quit.")

    while True:
        ok, frame = cap.read()
        if not ok:
            print("[main] Failed to read from webcam, stopping.")
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w = frame.shape[:2]
        now = time.time()

        # ---------------- SOS gesture ----------------
        hand_results = hands.process(rgb)
        gesture_triggered = False
        if hand_results.multi_hand_landmarks:
            for hand_landmarks in hand_results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                if is_distress_gesture(hand_landmarks.landmark):
                    gesture_triggered = True

        if gesture_triggered:
            gesture_since = gesture_since or now
            held_for = now - gesture_since
        else:
            gesture_since = None
            held_for = 0.0

        gesture_alert_active = held_for >= GESTURE_HOLD_SECONDS

        if gesture_alert_active and (now - last_gesture_alert) > COOLDOWN_SECONDS:
            last_gesture_alert = now
            write_status("sos_gesture", True, {"held_for": round(held_for, 2)})
            play_buzzer_async()
            send_sms_alert("Kavach Alert: possible distress hand gesture detected on bus feed.")

        # ---------------- driver drowsiness ----------------
        face_results = face_mesh.process(rgb)
        ear = None
        if face_results.multi_face_landmarks:
            landmarks = face_results.multi_face_landmarks[0].landmark
            ear = average_ear(landmarks)

        if ear is not None and ear < EAR_THRESHOLD:
            eyes_closed_since = eyes_closed_since or now
            closed_for = now - eyes_closed_since
        else:
            eyes_closed_since = None
            closed_for = 0.0

        drowsy_alert_active = closed_for >= EAR_CONSEC_SECONDS

        if drowsy_alert_active and (now - last_drowsy_alert) > COOLDOWN_SECONDS:
            last_drowsy_alert = now
            write_status("drowsiness", True, {"eyes_closed_for": round(closed_for, 2)})
            play_buzzer_async()
            send_sms_alert("Kavach Alert: driver drowsiness detected.")

        if not gesture_alert_active and not drowsy_alert_active:
            write_status("normal", False)

        # ---------------- overlay UI ----------------
        border_color = (60, 60, 60)
        label = "Kavach: monitoring"
        if gesture_alert_active:
            border_color = (0, 0, 255)
            label = "ALERT: SOS gesture detected"
        elif drowsy_alert_active:
            border_color = (0, 0, 255)
            label = "ALERT: driver drowsiness detected"

        cv2.rectangle(frame, (0, 0), (w - 1, h - 1), border_color, 8)
        cv2.putText(frame, label, (16, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.75, border_color, 2)
        if ear is not None:
            cv2.putText(frame, f"EAR: {ear:.2f}", (16, h - 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)

        cv2.imshow("Project Kavach - Live Feed", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
    hands.close()
    face_mesh.close()


if __name__ == "__main__":
    main()
