"""
Heuristic detector for a distress hand gesture, loosely modelled on the
public "Signal for Help" (palm out, thumb tucked in, fingers folding
down over the thumb).

IMPORTANT: this is a SIMPLIFIED heuristic built for a 2-day hackathon
demo. It flags "four fingers curled + thumb tucked toward the palm"
shown to the camera. It is not a validated, tested, or forensic-grade
gesture-recognition system, and it will have false positives/negatives.
Treat it as a starting point to refine (e.g. by requiring the motion
sequence: open palm -> fingers close -> hold), not a finished detector.
"""
import math

FINGER_TIPS = {"index": 8, "middle": 12, "ring": 16, "pinky": 20}
FINGER_PIPS = {"index": 6, "middle": 10, "ring": 14, "pinky": 18}
THUMB_TIP = 4
PALM_CENTER_REF = 9  # middle-finger MCP joint, a stable rough palm-center point
WRIST = 0

THUMB_TUCK_DISTANCE = 0.09  # normalized image-space threshold; tune per camera/distance


def _dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def is_finger_curled(landmarks, tip_idx, pip_idx, wrist_idx=WRIST):
    """A finger counts as curled if its tip sits closer to the wrist than its pip joint does."""
    tip = landmarks[tip_idx]
    pip = landmarks[pip_idx]
    wrist = landmarks[wrist_idx]
    return _dist(tip, wrist) < _dist(pip, wrist)


def is_thumb_tucked(landmarks):
    """True if the thumb tip sits close to the palm center (tucked in, not extended out)."""
    thumb_tip = landmarks[THUMB_TIP]
    palm_ref = landmarks[PALM_CENTER_REF]
    return _dist(thumb_tip, palm_ref) < THUMB_TUCK_DISTANCE


def is_distress_gesture(landmarks):
    """
    landmarks: list of 21 mediapipe NormalizedLandmark points for one hand
    (hand_landmarks.landmark from MediaPipe Hands).

    Returns True if all four fingers are curled AND the thumb is tucked in.
    """
    curled = [
        is_finger_curled(landmarks, FINGER_TIPS[f], FINGER_PIPS[f])
        for f in FINGER_TIPS
    ]
    return all(curled) and is_thumb_tucked(landmarks)
