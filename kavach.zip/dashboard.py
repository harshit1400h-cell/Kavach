"""
Project Kavach — Central Command Dashboard (Streamlit).

Polls status.json (written by main.py) and shows a live "control room"
view: an alert banner, a simulated bus location on a map, and an audio
chime that plays once per new alert.

Run in a SEPARATE terminal from main.py:
    streamlit run dashboard.py
"""
import base64
import time

import streamlit as st

from alerts import read_status
from make_buzzer import ASSETS_DIR, generate_buzzer

st.set_page_config(page_title="Kavach Command Center", page_icon="\U0001F6E1", layout="wide")

# Simulated bus GPS location — swap for a real live feed in production
BUS_LAT, BUS_LON = 28.6139, 77.2090  # placeholder: New Delhi

st.title("\U0001F6E1 Kavach — Central Transit Command Center")
st.caption("Live monitoring demo. Run `python main.py` in another terminal to feed it alerts.")

status_box = st.empty()
map_box = st.empty()
audio_box = st.empty()

if "last_alert_ts" not in st.session_state:
    st.session_state.last_alert_ts = None


def get_chime_base64():
    wav_path = ASSETS_DIR / "buzzer.wav"
    if not wav_path.exists():
        generate_buzzer(wav_path)
    return base64.b64encode(wav_path.read_bytes()).decode()


status = read_status()

with status_box.container():
    if status["active"]:
        st.error(
            f"\U0001F6A8 ACTIVE ALERT — {status['event_type'].replace('_', ' ').title()}  \n"
            f"Details: {status['extra']}"
        )
    else:
        st.success("\u2705 No active alerts — all monitored vehicles normal.")

with map_box.container():
    st.subheader("Live Fleet Map (simulated)")
    st.map({"lat": [BUS_LAT], "lon": [BUS_LON]}, zoom=11)

# Play a chime once per *new* alert, not on every refresh
if status["active"] and status["timestamp"] != st.session_state.last_alert_ts:
    st.session_state.last_alert_ts = status["timestamp"]
    b64 = get_chime_base64()
    with audio_box.container():
        st.markdown(
            f'<audio autoplay><source src="data:audio/wav;base64,{b64}" type="audio/wav"></audio>',
            unsafe_allow_html=True,
        )

# Simple polling loop for a hackathon demo. For production, replace this
# with st.fragment(run_every=...) (Streamlit 1.33+) instead of a manual
# sleep + rerun, which reruns the whole script each time.
time.sleep(2)
st.rerun()
