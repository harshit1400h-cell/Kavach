# Project Kavach — Hackathon Prototype

A local, two-process demo of the Kavach concept: a webcam acts as the "bus
CCTV" feed, a detection engine watches for a distress hand gesture and
driver drowsiness, and a Streamlit dashboard acts as the central command
center.

## What's included

| File | Purpose |
|---|---|
| `main.py` | Detection engine — opens the webcam, runs MediaPipe Hands + FaceMesh, triggers alerts |
| `gesture_utils.py` | Heuristic "distress gesture" detector (curled fingers + tucked thumb) |
| `ear_utils.py` | Eye Aspect Ratio calculation for drowsiness detection |
| `alerts.py` | Writes `status.json` for the dashboard; optionally sends SMS via Twilio |
| `make_buzzer.py` | Generates a synthetic buzzer tone with no external audio asset needed |
| `dashboard.py` | Streamlit "command center" UI — reads `status.json`, shows alerts + map + chime |
| `requirements.txt` | Python dependencies |
| `.env.example` | Template for optional Twilio credentials |

## Setup

```bash
cd kavach
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**Note on the `mediapipe==0.10.14` pin:** newer mediapipe releases (0.10.30+
/ 1.0.x) removed the legacy `mp.solutions.hands` / `mp.solutions.face_mesh`
API that `main.py` uses, in favor of a new "Tasks" API that needs separate
downloaded model files. Installing an unpinned `mediapipe` will crash with
`AttributeError: module 'mediapipe' has no attribute 'solutions'` the
moment `main.py` runs. `requirements.txt` pins a version confirmed to still
have the legacy API — don't remove the pin unless you port `main.py` to
the Tasks API.

You may see a pip warning that this mediapipe version wants an older
`protobuf` than `streamlit` asks for. In testing, both still imported and
ran fine together despite the warning — but if you hit a real protobuf
error, try `pip install "protobuf>=4.25,<5"` explicitly.

If you want real SMS alerts, copy `.env.example` to `.env` and fill in
your Twilio credentials. If you skip this, the demo still runs end-to-end
— `send_sms_alert()` just logs a note and continues.

## Running the demo

Open **two terminals** in the `kavach` folder:

```bash
# Terminal 1 — detection engine
python main.py
```

```bash
# Terminal 2 — dashboard
streamlit run dashboard.py
```

- In the webcam window, hold up a closed fist with your thumb tucked in
  toward your palm for about half a second to trigger the "SOS gesture" alert.
- Close your eyes for 2+ seconds to trigger the "drowsiness" alert.
- Watch the Streamlit dashboard flip to a red alert banner with a chime
  within a couple of seconds of either trigger.
- Press `q` in the video window to quit `main.py`.

## Important limitations (read before a demo or any real deployment)

- **The gesture detector is a simplified heuristic**, not a validated
  gesture-recognition model. It looks for "four fingers curled + thumb
  tucked" in a single frame. It will false-positive on some natural hand
  shapes and can miss the real signal at bad angles or lighting. For a
  stronger demo, consider requiring the *sequence* (open palm → fingers
  close over thumb → held), not just the end pose.
- **EAR-based drowsiness detection** is a well-established technique but
  is sensitive to camera angle, glasses, and lighting — tune
  `EAR_THRESHOLD` in `main.py` against your own webcam before demoing.
- This is a **local single-camera prototype**, not a production safety
  system. A real deployment would need: consent/privacy review for
  continuous audio+video monitoring of passengers, a tested and validated
  gesture/audio model (ideally trained on the target population and
  camera hardware), human review before dispatching police, and
  compliance with local surveillance and data-protection law.
- The audio anomaly detection (screams/aggressive pitch) described in the
  original concept is **not implemented here** — this starter covers the
  gesture + drowsiness pipeline only. A basic version could be added with
  `librosa`: compute short-time RMS amplitude and pitch, and flag sudden
  spikes above a rolling baseline.

## Suggested next steps

1. Add the audio anomaly module (`librosa` + microphone input).
2. Replace the single-frame gesture heuristic with a short temporal
   window (e.g. track the gesture state across N frames).
3. Swap the simulated bus location in `dashboard.py` for a real GPS feed.
4. Add a simple auth layer to the dashboard before using it beyond a demo.
