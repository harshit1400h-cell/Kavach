"""
Central alert dispatcher for Project Kavach.

- write_status()/read_status(): a tiny file-based message bus. main.py
  (the detection engine) writes to status.json; dashboard.py (Streamlit)
  polls it. This keeps the two processes decoupled and easy to demo.
- send_sms_alert(): sends a real SMS via Twilio if credentials are set
  in the environment (or a .env file). If they're not set, it prints a
  note and no-ops, so the rest of the demo still runs end-to-end.
"""
import json
import os
import time
from pathlib import Path

STATUS_FILE = Path(__file__).parent / "status.json"


def _load_env():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass  # python-dotenv is optional; you can export env vars directly instead


_load_env()

TWILIO_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_FROM = os.getenv("TWILIO_FROM_NUMBER")
ALERT_TO = os.getenv("ALERT_TO_NUMBER")


def write_status(event_type, active, extra=None):
    """
    event_type: "sos_gesture" | "drowsiness" | "normal"
    active: bool — whether an alert is currently active
    extra: optional dict of extra fields (e.g. confidence, bus_id, duration)
    """
    payload = {
        "event_type": event_type,
        "active": active,
        "timestamp": time.time(),
        "extra": extra or {},
    }
    STATUS_FILE.write_text(json.dumps(payload, indent=2))


def read_status():
    if not STATUS_FILE.exists():
        return {"event_type": "normal", "active": False, "timestamp": time.time(), "extra": {}}
    try:
        return json.loads(STATUS_FILE.read_text())
    except json.JSONDecodeError:
        return {"event_type": "normal", "active": False, "timestamp": time.time(), "extra": {}}


def send_sms_alert(message):
    """
    Sends an SMS via Twilio if TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,
    TWILIO_FROM_NUMBER and ALERT_TO_NUMBER are all set (e.g. in a .env
    file — see .env.example). Otherwise it just logs and returns False,
    so you can demo the rest of the pipeline without a Twilio account.
    """
    if not all([TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM, ALERT_TO]):
        print(
            "[alerts] Twilio not configured — skipping SMS. Set "
            "TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER, "
            "ALERT_TO_NUMBER (e.g. in a .env file) to enable real SMS alerts."
        )
        return False
    try:
        from twilio.rest import Client
        client = Client(TWILIO_SID, TWILIO_TOKEN)
        client.messages.create(body=message, from_=TWILIO_FROM, to=ALERT_TO)
        print("[alerts] SMS sent.")
        return True
    except Exception as e:
        print(f"[alerts] Failed to send SMS: {e}")
        return False
