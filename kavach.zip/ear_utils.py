"""
Eye Aspect Ratio (EAR) utility for driver drowsiness detection.
Uses MediaPipe FaceMesh landmark indices for the eyes.

EAR drops sharply when the eyes close, so tracking it over time lets us
detect "eyes closed for N seconds" without any heavy ML model.
"""
import math

# MediaPipe FaceMesh landmark indices for the standard 6-point EAR scheme
LEFT_EYE = [362, 385, 387, 263, 373, 380]
RIGHT_EYE = [33, 160, 158, 133, 153, 144]


def _dist(p1, p2):
    return math.hypot(p1.x - p2.x, p1.y - p2.y)


def eye_aspect_ratio(landmarks, eye_indices):
    """
    landmarks: list of mediapipe NormalizedLandmark objects (468 points from FaceMesh)
    eye_indices: 6 indices in EAR order [p1, p2, p3, p4, p5, p6]
    EAR = (|p2-p6| + |p3-p5|) / (2 * |p1-p4|)
    """
    p = [landmarks[i] for i in eye_indices]
    vertical_1 = _dist(p[1], p[5])
    vertical_2 = _dist(p[2], p[4])
    horizontal = _dist(p[0], p[3])
    if horizontal == 0:
        return 0.0
    return (vertical_1 + vertical_2) / (2.0 * horizontal)


def average_ear(landmarks):
    """Average EAR across both eyes — more stable than either eye alone."""
    left = eye_aspect_ratio(landmarks, LEFT_EYE)
    right = eye_aspect_ratio(landmarks, RIGHT_EYE)
    return (left + right) / 2.0
